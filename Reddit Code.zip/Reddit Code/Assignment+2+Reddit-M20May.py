
# coding: utf-8

# In[77]:

####Hypothesis: Which DC Marvel Hero is the most popular?


# In[78]:

import string
import re
import tweepy
import json
import twitterClient
from collections import Counter
import networkx as nx

import nltk
from nltk.tokenize import TweetTokenizer
from nltk.corpus import stopwords
from nltk.sentiment.vader import SentimentIntensityAnalyzer
from nltk.corpus import opinion_lexicon

from sklearn.feature_extraction.text import CountVectorizer
from sklearn.decomposition import LatentDirichletAllocation
from scipy.stats.stats import pearsonr

from colorama import Fore, Style
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
get_ipython().magic("config InlineBackend.figure_format = 'retina'")
plt.style.use('seaborn')
pd.set_option('display.max_columns', None)  
pd.options.display.max_colwidth = 200


# In[79]:

import nltk
nltk.download('stopwords')


# In[80]:

from nltk.sentiment.vader import SentimentIntensityAnalyzer as SIA
nltk.download('opinion_lexicon')


# In[14]:

## Extension 1.1: Reddit Sentiment Analysis


# In[62]:

"""
@author Megha Mohan
"""
import praw
import time
import random
import sys
import csv
import math
import numpy as np
import pandas as pd
from collections import Counter
import networkx as nx

import nltk
nltk.download('punkt')

from colorama import Fore, Style

import matplotlib.pyplot as plt
from fuzzywuzzy import fuzz
from IPython.display import display
from IPython.display import clear_output
from pprint import pprint
from ipywidgets import IntSlider, Output
from IPython.display import clear_output
import datetime as dt
import matplotlib.pyplot as plt
get_ipython().magic("config InlineBackend.figure_format = 'retina'")
plt.style.use('seaborn')
pd.set_option('display.max_columns', None)  
pd.options.display.max_colwidth = 200
import seaborn as sns


# In[63]:

reddit = praw.Reddit(client_id='PiURtsGqnsmLEA',
client_secret='JodQ8pfG4OJ1TiYQPvkjcCAlG6s',
user_agent='SocialMedia')


# In[158]:

headlines = set()
for submission in reddit.subreddit('avengers').new(limit=None):
    headlines.add(submission.title)
clear_output()


# In[159]:

from nltk.sentiment.vader import SentimentIntensityAnalyzer as SIA

sia = SIA()
results = []

for line in headlines:
    pol_score = sia.polarity_scores(line)
    pol_score['headlines'] = line
    results.append(pol_score)

pprint(results[:3], width=500)


# In[160]:

df = pd.DataFrame.from_records(results)
df.head()


# In[161]:

df['label'] = 0
df.loc[df['compound'] > 0.2, 'label'] = 1
df.loc[df['compound'] < -0.2, 'label'] = -1
df.head()


# In[162]:

df2 = df[['headlines','label']]


# In[163]:

df2.to_csv('reddit3_headlines_labels.csv', mode='a', encoding='utf-8', index=False)


# In[164]:

df.label.value_counts()


# In[165]:

print("Positive headlines:\n")
pprint(list(df[df['label'] == 1].headlines)[:5], width=200)

print("\nNegative headlines:\n")
pprint(list(df[df['label'] == -1].headlines)[:5], width=200)


# In[166]:

df.label.value_counts(normalize=True) * 100


# In[167]:

fig, ax = plt.subplots(figsize=(8, 8))
counts = df.label.value_counts(normalize=True) * 100
sns.barplot(x=counts.index, y=counts, ax=ax, color="salmon")
ax.set_xticklabels(['Negative', 'Neutral', 'Positive'])
ax.set_ylabel("Percentage")
plt.show()


# In[168]:

from nltk.tokenize import word_tokenize, RegexpTokenizer


# In[169]:

example = "Thor is the best movie ever"
print(word_tokenize(example, language='english'))


# In[170]:

tokenizer = RegexpTokenizer(r'\w+')
print(tokenizer.tokenize(example))


# In[171]:

from nltk.corpus import stopwords

stop_words = stopwords.words('english')
print(stop_words[:20])


# In[172]:

def process_text(headlines):
    tokens = []
    for line in headlines:
        line = line.lower()
        toks = tokenizer.tokenize(line)
        toks = [t for t in toks if t not in stop_words]
        tokens.extend(toks)
    
    return tokens


# In[173]:

pos_lines = list(df[df.label == 1].headlines)

pos_tokens = process_text(pos_lines)
pos_freq = nltk.FreqDist(pos_tokens)

pos_freq.most_common(20)


# In[174]:


y_val = [x[1] for x in pos_freq.most_common()]
fig = plt.figure(figsize=(10,5))
plt.plot(y_val)
plt.xlabel("Words")
plt.ylabel("Frequency")
plt.title("Word Frequency Distribution (Positive)")
plt.show()


# In[175]:

y_final = []
for i, k, z, t in zip(y_val[0::4], y_val[1::4], y_val[2::4], y_val[3::4]):
    y_final.append(math.log(i + k + z + t))

x_val = [math.log(i + 1) for i in range(len(y_final))]

fig = plt.figure(figsize=(10,5))

plt.xlabel("Words (Log)")
plt.ylabel("Frequency (Log)")
plt.title("Word Frequency Distribution (Positive)")
plt.plot(x_val, y_final)
plt.show()


# In[176]:

neg_lines = list(df2[df2.label == -1].headlines)

neg_tokens = process_text(neg_lines)
neg_freq = nltk.FreqDist(neg_tokens)

neg_freq.most_common(20)


# In[177]:

y_val = [x[1] for x in neg_freq.most_common()]

fig = plt.figure(figsize=(10,5))
plt.plot(y_val)

plt.xlabel("Words")
plt.ylabel("Frequency")
plt.title("Word Frequency Distribution (Negative)")
plt.show()


# In[178]:


y_final = []
for i, k, z in zip(y_val[0::3], y_val[1::3], y_val[2::3]):
    if i + k + z == 0:
        break
    y_final.append(math.log(i + k + z))

x_val = [math.log(i+1) for i in range(len(y_final))]

fig = plt.figure(figsize=(10,5))

plt.xlabel("Words (Log)")
plt.ylabel("Frequency (Log)")
plt.title("Word Frequency Distribution (Negative)")
plt.plot(x_val, y_final)
plt.show()


# In[179]:

## Extension 1.2: Network Node Map for Streaming Media from Reddit web scrape data 


# In[180]:

import plotly.offline as py
from plotly.graph_objs import *
from operator import itemgetter
import community
import networkx as nx
import colorlover as cl
import numpy as np
import pickle
from nltk.stem import WordNetLemmatizer, PorterStemmer
from string import punctuation
from collections import Counter
from operator import itemgetter
import community
from collections import OrderedDict
import re
import warnings
warnings.filterwarnings("ignore", category=DeprecationWarning)
import matplotlib.pyplot as plt
from bs4 import BeautifulSoup


# In[181]:

###Streaming Video
subreddit = reddit.subreddit('avengers')
top_subreddit = subreddit.top(limit=1000)


# In[182]:

for submission in subreddit.top(limit=2):
    print(submission.title, submission.id)


# In[248]:

#topics_dict = { "title",       "producer" }
import pandas as pd
mydict=pd.read_csv('vidstream1.csv', header=None, dtype={0: str}).set_index(0).squeeze().to_dict()


# In[249]:

get_ipython().magic('matplotlib inline')
get_ipython().magic('pylab inline')
import pandas as pd
import networkx as nx
import matplotlib.pyplot as plt

# Ignore matplotlib warnings
import warnings
warnings.filterwarnings("ignore")

df = pd.read_csv("vidstream1.csv")
df.head()


# In[250]:

g = nx.from_pandas_dataframe(df, source='title', target='Producer') 
nx.draw(g)


# In[251]:

vid = list(df.title.unique())
prod = list(df.Producer.unique())
prod


# In[252]:

# How many streaming shows does HBO have coming out of it?
g.degree('HBO')


# In[253]:

prod_size=[g.degree(prod) for prod in prod]


# In[260]:

import matplotlib.pyplot as plt

plt.figure(figsize=(12, 12))

# 1. Create the graph
g = nx.from_pandas_dataframe(df, source='title', target='Producer') 

# 2. Create a layout for our nodes 
layout = nx.spring_layout(g,iterations=50)

# 3. Draw the parts we want
nx.draw_networkx_edges(g, layout, edge_color='#AAAAAA')

prods = [node for node in g.nodes() if node in df.Producer.unique()]
size = [g.degree(node) * 80 for node in g.nodes() if node in df.Producer.unique()]
nx.draw_networkx_nodes(g, layout, nodelist=prod, node_size=size, node_color='lightblue')

people = [node for node in g.nodes() if node in df.title.unique()]
nx.draw_networkx_nodes(g, layout, nodelist=vid, node_size=10, node_color='#AAAAAA')

mydict = dict(zip(prod, [prod]))
nx.draw_networkx_labels(g, layout, labels=mydict)

# 4. Turn off the axis because I know you don't want it
plt.axis('off')
plt.title("Most popular streaming videos")

# 5. Tell matplotlib to show it
plt.show()


# In[ ]:




# In[ ]:



